package com.zybooks.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 3;
    private static final String TABLE_EVENTS = "inventory_events";

    private static InventoryDatabase instance;

    public static synchronized InventoryDatabase getInstance(Context context){
        if (instance == null){
            instance = new InventoryDatabase(context.getApplicationContext());
        }
        return instance;
    }

    private InventoryDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "Inventory";
        private static final String COL_ID = "Item_Number";
        private static final String Col_Item= "Item";
        private static final String Col_Qty = "Quantity";
    }
    private static final String CREATE_EVENTS_TABLE =
            "CREATE TABLE " + TABLE_EVENTS + " (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "itemName TEXT NOT NULL, " +
                    "action TEXT NOT NULL, " +
                    "timestamp INTEGER NOT NULL)";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryTable.Col_Item + " TEXT NOT NULL, " +
                InventoryTable.Col_Qty + " INTEGER NOT NULL)");
        db.execSQL((CREATE_EVENTS_TABLE));
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    public void addItem(String item, int qty){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.Col_Item, item);
        values.put(InventoryTable.Col_Qty, qty);
        try {
            db.insertOrThrow(InventoryTable.TABLE, null, values);
            logEvent(item, "ADDED NEW ITEM");
        } catch (SQLException e) {
            System.out.println("Item already exists");
            logEvent(item, "FAILED TO ADD NEW ITEM");
        }
    }

    public void deleteItem(String itemNumber) {
        SQLiteDatabase db = getWritableDatabase();
        try {
            db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?", new String[]{itemNumber});

            String itemName = getItemNameById(itemNumber);
            logEvent(itemName, "ITEM DELETED");

        } catch (SQLException e) {
            String itemName = getItemNameById(itemNumber);
            logEvent(itemName, "ITEM NOT FOUND");
        }
    }

    public void adjustQty(String itemNumber, int newQty){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.Col_Qty, newQty);

        try {
            db.update(InventoryTable.TABLE, values, InventoryTable.COL_ID + " = ? ", new String[]{itemNumber});

            String itemName = getItemNameById(itemNumber);
            logEvent(itemName, "QUANTITY CHANGED to " + newQty);

        } catch (SQLException e) {
            String itemName = getItemNameById(itemNumber);
            logEvent(itemName, "FAILED TO CHANGE QUANTITY");
        }
    }

    public List<InventoryItem> getAllItems(){
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int qty = cursor.getInt(2);
                itemList.add(new InventoryItem(id, name, qty));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    public void logEvent(String itemName, String action) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values =  new ContentValues();
        values.put("itemName", itemName);
        values.put("action", action);
        values.put("timestamp", System.currentTimeMillis());

        db.insert(TABLE_EVENTS, null, values);
    }
    public String getItemNameById(String itemId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT " + InventoryTable.Col_Item +
                        " FROM " + InventoryTable.TABLE +
                        " WHERE " + InventoryTable.COL_ID + " = ?",
                new String[]{itemId}
        );

        if (cursor.moveToFirst()) {
            String name = cursor.getString(0);
            cursor.close();
            return name;
        }

        cursor.close();
        return "UNKNOWN ITEM";
    }

}
