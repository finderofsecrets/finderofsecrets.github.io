package com.zybooks.cs360project;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.Objects;

import kotlinx.serialization.descriptors.PrimitiveKind;

public class UserLoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;
    public UserLoginDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static final class LoginsTable {
        public static final String TABLE = "Logins";
        public static final String COL_ID = "_id";
        public static final String Col_Username = "Username";
        public static final String Col_Password = "Password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + LoginsTable.TABLE + " (" +
                LoginsTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                LoginsTable.Col_Username + " TEXT NOT NULL UNIQUE, " +
                LoginsTable.Col_Password + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + LoginsTable.TABLE);
        onCreate(db);
    }

    public void addUser(String username, String Password, String ConfirmPassword){
        if (!Objects.equals(Password, ConfirmPassword)){
            System.out.println("Passwords do not match.");
            return;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginsTable.Col_Username, username);
        values.put(LoginsTable.Col_Password, Password);
        try {
            db.insertOrThrow(LoginsTable.TABLE, null, values);
        } catch (SQLException e) {
            System.out.println("Username already exists");
        }
    }

    public boolean findUserLogin(String username, String password){
    SQLiteDatabase db = getReadableDatabase();
    Cursor cursor = null;
    try {
        String[] columns = {LoginsTable.Col_Username};
        String selection = LoginsTable.Col_Username + " = ? AND " + LoginsTable.Col_Password + " = ?";
        // Trim input to avoid spaces
        String[] selectionArgs = {username.trim(), password.trim()};
        cursor = db.query(
                LoginsTable.TABLE,
                columns,
                selection,
                selectionArgs,
                null, null, null
        );
        return cursor.getCount() > 0;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    } finally {
        if (cursor != null) cursor.close();
    }
}
    // Update the password for an existing user
    public void updatePassword(String username, String newPassword) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(LoginsTable.Col_Password, newPassword);
        int rowsUpdated = db.update(
                LoginsTable.TABLE,
                values,
                LoginsTable.Col_Username + " = ?",
                new String[]{username}
        );
    }
    // Returns true if the username exists in the database
    public boolean checkUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            String[] columns = {LoginsTable.Col_Username};
            String selection = LoginsTable.Col_Username + " = ?";
            String[] selectionArgs = {username};

            cursor = db.query(
                    LoginsTable.TABLE,
                    columns,
                    selection,
                    selectionArgs,
                    null, null, null
            );

            return cursor.getCount() > 0;
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}
