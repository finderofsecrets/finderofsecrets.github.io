package com.zybooks.cs360project.data.analytics;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.HashMap;
import java.util.Map;

//implement a form of datamining to help create analytics for users.
public class InventoryDataMiner {

    public String mostModifiedItem(SQLiteDatabase db) {
        String query =
                "SELECT itemName, COUNT(*) AS count " +
                        "FROM inventory_events " +
                        "GROUP BY itemName " +
                        "ORDER BY count DESC LIMIT 1";

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            String item = cursor.getString(0);
            cursor.close();
            return item;
        }

        cursor.close();
        return "N/A";
    }

    public double averageEventsPerDay(SQLiteDatabase db) {
        Cursor cursor = db.rawQuery(
                "SELECT MIN(timestamp), MAX(timestamp), COUNT(*) FROM inventory_events",
                null
        );

        if (cursor.moveToFirst()) {
            long min = cursor.getLong(0);
            long max = cursor.getLong(1);
            int count = cursor.getInt(2);

            cursor.close();

            double days = (max - min) / 86_400_000.0;
            return count / Math.max(days, 1);
        }

        cursor.close();
        return 0;
    }
    public Map<String, Integer> eventsPerItem(SQLiteDatabase db) {
        Map<String, Integer> map = new HashMap<>();

        // SQL query: count events grouped by item name
        String query = "SELECT itemName, COUNT(*) FROM inventory_events GROUP BY itemName";
        Cursor cursor = db.rawQuery(query, null);

        while (cursor.moveToNext()) {
            String itemName = cursor.getString(0);
            int count = cursor.getInt(1);
            map.put(itemName, count);
        }

        cursor.close();
        return map;
    }

}
