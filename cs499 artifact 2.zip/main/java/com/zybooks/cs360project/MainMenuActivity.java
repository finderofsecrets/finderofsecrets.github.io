package com.zybooks.cs360project;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.zybooks.cs360project.ui.AnalyticsActivity;


public class MainMenuActivity extends AppCompatActivity {
    private Button manageInventory;
    private Button itemSearch;
    private Button itemReplen;
    private Button analyticsButton;
    private static final int REQUEST_SEND_SMS = 123;


    private void requestSmsPermission(){
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) !=PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SEND_SMS);
        } else {
        sendLowInventoryAlert();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SEND_SMS) {
            if((grantResults.length > 0) && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                requestSmsPermission();
            } else {
                Toast.makeText(this, "SMS Permission denied. SMS alerts disabled", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendLowInventoryAlert(){
        String phoneNumber = "(650) 555-1212";
        String message = "Inventory Alert: An item is low on stock.";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

        Toast.makeText(this, "SMS alert sent", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //EdgeToEdge.enable(this);
        requestSmsPermission();
        setContentView(R.layout.activity_main_menu);

        manageInventory = findViewById(R.id.ManageInventoryButton);

        manageInventory.setOnClickListener(v -> {
            //Toast.makeText(this, "Button Clicked!", Toast.LENGTH_SHORT).show();
            //Log.d("MainMenuActivity", "Manage Inventory Button Clicked");
            Intent intent = new Intent(MainMenuActivity.this, InventoryActivity.class);
            startActivity(intent);
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        requestSmsPermission();

        itemSearch = findViewById(R.id.button2);

        itemSearch.setOnClickListener(v ->{
            Toast.makeText(this, "Item Search is Coming Soon!", Toast.LENGTH_SHORT).show();
        });
        itemReplen = findViewById(R.id.button3);

        itemReplen.setOnClickListener( v -> {
            Toast.makeText(this, "Replen is Coming Soon!", Toast.LENGTH_SHORT).show();
        });

        analyticsButton = findViewById(R.id.buttonAnalytics);

        analyticsButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenuActivity.this, AnalyticsActivity.class);
            startActivity(intent);
        });

    }
}