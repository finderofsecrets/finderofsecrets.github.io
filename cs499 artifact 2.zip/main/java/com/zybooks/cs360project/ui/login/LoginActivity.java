package com.zybooks.cs360project.ui.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.zybooks.cs360project.MainMenuActivity;
import com.zybooks.cs360project.R;
import com.zybooks.cs360project.UserLoginDatabase;
import com.zybooks.cs360project.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private LoginViewModel loginViewModel;
    private UserLoginDatabase userLoginDatabase;
    private ActivityLoginBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        userLoginDatabase = new UserLoginDatabase(this);
        loginViewModel = new ViewModelProvider(this,
                new LoginViewModelFactory(this))
                .get(LoginViewModel.class);

        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final Button loginButton = binding.login;
        final ProgressBar loadingProgressBar = binding.loading;
        final Button forgotPasswordButton = binding.buttonForgotPassword;

        // Enable/disable login button based on input
        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(
                        usernameEditText.getText().toString(),
                        passwordEditText.getText().toString()
                );
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);

        // Observe form state for errors
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(LoginFormState state) {
                if (state == null) return;
                loginButton.setEnabled(state.isDataValid());
                if (state.getUsernameError() != null)
                    usernameEditText.setError(getString(state.getUsernameError()));
                if (state.getPasswordError() != null)
                    passwordEditText.setError(getString(state.getPasswordError()));
            }
        });

        // Observe login result
        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(LoginResult result) {
                if (result == null) return;
                loadingProgressBar.setVisibility(android.view.View.GONE);
                if (result.getError() != null) {
                    Toast.makeText(getApplicationContext(), result.getError(), Toast.LENGTH_SHORT).show();
                }
                if (result.getSuccess() != null) {
                    Toast.makeText(getApplicationContext(),
                            getString(R.string.welcome) + result.getSuccess().getDisplayName(),
                            Toast.LENGTH_LONG).show();
                    startActivity(new Intent(LoginActivity.this, MainMenuActivity.class));
                    finish();
                }
            }
        });

        // Login button click → login or auto-register
        loginButton.setOnClickListener(v -> {
            loadingProgressBar.setVisibility(android.view.View.VISIBLE);
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();
            loginViewModel.login(username, password, password); // password used for confirm
        });

        // Forgot password flow
        forgotPasswordButton.setOnClickListener(v -> showForgotPasswordDialog());

        // Optional: handle "done" action on keyboard
        passwordEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                loginButton.performClick();
            }
            return false;
        });
    }

    // Allow user to manually reset their password
    private void showForgotPasswordDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Reset Password");

        final EditText usernameInput = new EditText(this);
        usernameInput.setHint("Enter your username");

        final EditText newPasswordInput = new EditText(this);
        newPasswordInput.setHint("Enter new password");
        newPasswordInput.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);
        layout.addView(usernameInput);
        layout.addView(newPasswordInput);

        builder.setView(layout);

        builder.setPositiveButton("Set Password", (dialog, which) -> {
            String username = usernameInput.getText().toString().trim();
            String newPassword = newPasswordInput.getText().toString().trim();

            if (username.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(this, "Username and password cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!userLoginDatabase.checkUsernameExists(username)) {
                Toast.makeText(this, "Username not found", Toast.LENGTH_SHORT).show();
                return;
            }

            if (newPassword.length() <= 5) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
                return;
            }

            userLoginDatabase.updatePassword(username, newPassword);
            Toast.makeText(this, "Password updated successfully", Toast.LENGTH_LONG).show();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}
