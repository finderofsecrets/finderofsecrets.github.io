package com.zybooks.cs360project.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Patterns;

import com.zybooks.cs360project.UserLoginDatabase;
import com.zybooks.cs360project.R;
import com.zybooks.cs360project.data.model.LoggedInUser;

import java.util.Objects;

public class LoginViewModel extends ViewModel {

    private final MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private final MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private final UserLoginDatabase userLoginDatabase;

    private static final int MIN_PASSWORD_LENGTH = 6; // set minimum length here

    public LoginViewModel(Context context){
        userLoginDatabase = new UserLoginDatabase(context);
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    /** Handles login attempt */
    public void login(String username, String password, String confirmPassword) {
        username = username.trim();
        password = password.trim();
        confirmPassword = confirmPassword.trim();

        if (username.isEmpty() || password.isEmpty()) {
            loginResult.setValue(new LoginResult(R.string.login_failed));
            return;
        }

        if (userLoginDatabase.checkUsernameExists(username)) {
            // User exists, check password
            boolean validUser = userLoginDatabase.findUserLogin(username, password);
            if (validUser) {
                loginResult.setValue(new LoginResult(new LoggedInUserView(username)));
            } else {
                loginResult.setValue(new LoginResult(R.string.incorrect_password));
            }
        } else {
            // User does not exist, create account
            if (!Objects.equals(password, confirmPassword)) {
                loginResult.setValue(new LoginResult(R.string.passwords_do_not_match));
            return;
        }
        userLoginDatabase.addUser(username, password, confirmPassword);
        loginResult.setValue(new LoginResult(new LoggedInUserView(username)));
    }
}

    /** Checks if username already exists in DB */
    private boolean checkUsernameExists(String username) {
        SQLiteDatabase db = userLoginDatabase.getReadableDatabase();
        Cursor cursor = null;
        try {
            String[] columns = {UserLoginDatabase.LoginsTable.Col_Username};
            String selection = UserLoginDatabase.LoginsTable.Col_Username + " = ?";
            String[] selectionArgs = {username};
            cursor = db.query(UserLoginDatabase.LoginsTable.TABLE, columns, selection, selectionArgs, null, null, null);
            return cursor.getCount() > 0;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    /** Called when login form fields change */
    public void loginDataChanged(String username, String password) {
        if (!isUserNameValid(username)) {
            loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
        } else if (!isPasswordValid(password)) {
            loginFormState.setValue(new LoginFormState(null, R.string.password_too_short));
        } else {
            loginFormState.setValue(new LoginFormState(true));
        }
    }

    /** Username validation */
    private boolean isUserNameValid(String username) {
        if (username == null) return false;
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
            return !username.trim().isEmpty();
        }
    }

    /** Password validation */
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() >= MIN_PASSWORD_LENGTH;
    }
}