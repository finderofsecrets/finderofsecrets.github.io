package com.zybooks.cs360project.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.cs360project.R;

import java.util.List;

public class EventItemAdapter extends RecyclerView.Adapter<EventItemAdapter.ViewHolder> {

    private final List<EventItem> items;

    public EventItemAdapter(List<EventItem> items) {
        this.items = items;
    }

    // ViewHolder class
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCount;
        public ViewHolder(View view) {
            super(view);
            tvName = view.findViewById(R.id.tvItemName);
            tvCount = view.findViewById(R.id.tvItemCount);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_event, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        EventItem item = items.get(position);
        holder.tvName.setText(item.name);
        holder.tvCount.setText(String.valueOf(item.count));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }
}
