package com.zybooks.cs360project.ui;

public class EventItem {
    public final String name;
    public final int count;

    public EventItem(String name, int count) {
        this.name = name;
        this.count = count;
    }
}