package com.zybooks.cs360project.ui;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.cs360project.InventoryDatabase;
import com.zybooks.cs360project.InventoryItem;
import com.zybooks.cs360project.R;
import com.zybooks.cs360project.data.analytics.InventoryDataMiner;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class AnalyticsActivity extends AppCompatActivity {

    private InventoryDataMiner dataMiner;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analytics);
        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }

        // Initialize database and data miner
        InventoryDatabase dbHelper = InventoryDatabase.getInstance(this);
        db = dbHelper.getReadableDatabase();
        dataMiner = new InventoryDataMiner();

        // Back button
        ImageButton backButton = findViewById(R.id.imageButton);
        backButton.setOnClickListener(v -> finish());

        // Display all analytics
        displayAnalytics(dbHelper);
    }

    private void displayAnalytics(InventoryDatabase dbHelper) {
        // Fetch metrics
        List<InventoryItem> allItems = dbHelper.getAllItems();
        int totalItems = allItems.size();
        int totalQuantity = 0;
        for (InventoryItem item : allItems) {
            totalQuantity += item.getQty();
        }

        String mostModified = dataMiner.mostModifiedItem(db);
        double avgEvents = dataMiner.averageEventsPerDay(db);
        Map<String, Integer> eventsPerItem = dataMiner.eventsPerItem(db);

        // Update labeled metrics
        updateMetrics(totalItems, totalQuantity, mostModified, avgEvents);

        // Populate RecyclerView
        RecyclerView rv = findViewById(R.id.rvEventsPerItem);
        rv.setLayoutManager(new LinearLayoutManager(this));

        List<EventItem> list = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : eventsPerItem.entrySet()) {
            list.add(new EventItem(entry.getKey(), entry.getValue()));
        }

        EventItemAdapter adapter = new EventItemAdapter(list);
        rv.setAdapter(adapter);
    }

    private void updateMetrics(int totalItems, int totalQuantity, String mostModified, double avgEvents) {
        ((TextView) findViewById(R.id.tvValueTotalItems)).setText(String.valueOf(totalItems));
        ((TextView) findViewById(R.id.tvValueTotalQuantity)).setText(String.valueOf(totalQuantity));
        ((TextView) findViewById(R.id.tvValueMostModified)).setText(mostModified);
        ((TextView) findViewById(R.id.tvValueAvgEvents)).setText(String.format("%.2f", avgEvents));
    }
}
