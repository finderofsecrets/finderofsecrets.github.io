package com.zybooks.cs360project;

public class InventoryItem{
    private final int itemNumber;
    private final String itemName;
    private final int qty;

    public InventoryItem(int itemNumber, String itemName, int qty){
        this.itemName = itemName;
        this.itemNumber = itemNumber;
        this.qty = qty;
    }

    public int getItemNumber(){
        return itemNumber;
    }

    public String getItemName(){
        return itemName;
    }

    public int getQty(){
        return qty;
    }
}
