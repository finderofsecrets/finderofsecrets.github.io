package com.zybooks.cs360project;

import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;
import androidx.recyclerview.widget.GridLayoutManager;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private InventoryDatabase db;
    private InventoryAdapter adapters;
    private List<InventoryItem> itemList;
    private Button addItemButton;
    private Button adjustQtyButton;
    private Button deleteItemButton;
    private ImageButton back;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        if (getSupportActionBar() != null){
            getSupportActionBar().hide();
        }
        setContentView(R.layout.inventory);

        addItemButton = findViewById(R.id.addItemButton);
        adjustQtyButton = findViewById(R.id.adjustQtyButton);
        deleteItemButton = findViewById(R.id.deleteItemButton);
        back = findViewById(R.id.imageButton);

        addItemButton.setOnClickListener(v -> {
            // Show a dialog to input item name and quantity
            Toast.makeText(this, "Add Item clicked", Toast.LENGTH_SHORT).show();
        });

        adjustQtyButton.setOnClickListener(v -> {
            // You can prompt for item ID and new quantity
            Toast.makeText(this, "Adjust Quantity clicked", Toast.LENGTH_SHORT).show();
        });

        deleteItemButton.setOnClickListener(v -> {
            // Prompt for item ID to delete
            Toast.makeText(this, "Delete Item clicked", Toast.LENGTH_SHORT).show();
        });

        back.setOnClickListener(v -> {
            finish();
        });

        recyclerView = findViewById(R.id.inventoryRecyclerView);
        int numberOfColumns = 3;
        recyclerView.setLayoutManager(new GridLayoutManager(this,numberOfColumns));

        db = InventoryDatabase.getInstance(this);
        itemList = db.getAllItems();
        adapters = new InventoryAdapter(itemList);
        recyclerView.setAdapter(adapters);

        addItemButton.setOnClickListener(v -> {
            showAddItemDialog();
        });

        adjustQtyButton.setOnClickListener(v -> {
            showAdjustQuantityDialog();
        });

        deleteItemButton.setOnClickListener(v -> {
            showDeleteItemDialog();
        });



    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText itemNameInput = new EditText(this);
        itemNameInput.setHint("Item Name");
        layout.addView(itemNameInput);

        EditText itemQtyInput = new EditText(this);
        itemQtyInput.setHint("Quantity");
        itemQtyInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(itemQtyInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String name = itemNameInput.getText().toString();
            int qty = Integer.parseInt(itemQtyInput.getText().toString());
            db.addItem(name, qty);
            refreshInventoryList();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showAdjustQuantityDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Adjust Quantity");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        EditText itemIdInput = new EditText(this);
        itemIdInput.setHint("Item ID");
        itemIdInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(itemIdInput);

        EditText newQtyInput = new EditText(this);
        newQtyInput.setHint("New Quantity");
        newQtyInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(newQtyInput);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String id = itemIdInput.getText().toString();
            int newQty = Integer.parseInt(newQtyInput.getText().toString());
            db.adjustQty(id, newQty);
            refreshInventoryList();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showDeleteItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Item");

        final EditText itemIdInput = new EditText(this);
        itemIdInput.setHint("Item ID");
        itemIdInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        builder.setView(itemIdInput);

        builder.setPositiveButton("Delete", (dialog, which) -> {
            String id = itemIdInput.getText().toString();
            db.deleteItem(id);
            refreshInventoryList();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void refreshInventoryList() {
        itemList.clear();
        itemList.addAll(db.getAllItems());
        adapters.notifyDataSetChanged();
    }


}
