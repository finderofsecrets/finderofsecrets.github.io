package com.zybooks.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.Objects;

import kotlinx.serialization.descriptors.PrimitiveKind;

public class UserLoginDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "logins.db";
    private static final int VERSION = 1;
    public UserLoginDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static final class LoginsTable {
        public static final String TABLE = "Logins";
        public static final String COL_ID = "_id";
        public static final String Col_Username = "Username";
        public static final String Col_Password = "Password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + LoginsTable.TABLE + " (" +
                LoginsTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                LoginsTable.Col_Username + " TEXT NOT NULL UNIQUE, " +
                LoginsTable.Col_Password + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + LoginsTable.TABLE);
        onCreate(db);
    }

    public void addUser(String username, String Password, String ConfirmPassword){
        if (!Objects.equals(Password, ConfirmPassword)){
            System.out.println("Passwords do not match.");
            return;
        }

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginsTable.Col_Username, username);
        values.put(LoginsTable.Col_Password, Password);
        try {
            db.insertOrThrow(LoginsTable.TABLE, null, values);
        } catch (SQLException e) {
            System.out.println("Username already exists");
        }
    }

    public boolean findUserLogin(String username, String password){
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = null;
        try {
            String[] column = {LoginsTable.Col_Username};
            String confirmedUser = LoginsTable.Col_Username + " = ? " + " AND " + LoginsTable.Col_Password + " = ? ";
            String[] args = {username, password};
            cursor = db.query(LoginsTable.TABLE, column, confirmedUser, args, null, null, null);
            int count = cursor.getCount();
            cursor.close();
            return count > 0;
        } catch (Exception e) {
            System.out.println("Username or password is incorrect");
            if (cursor != null) {
                cursor.close();
            }
            return false;

        }

    }
}
