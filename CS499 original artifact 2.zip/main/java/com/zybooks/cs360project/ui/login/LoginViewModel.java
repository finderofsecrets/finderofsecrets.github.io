package com.zybooks.cs360project.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Patterns;

import com.zybooks.cs360project.UserLoginDatabase;
import com.zybooks.cs360project.data.LoginRepository;
import com.zybooks.cs360project.data.Result;
import com.zybooks.cs360project.data.model.LoggedInUser;
import com.zybooks.cs360project.R;

public class LoginViewModel extends ViewModel {

    private MutableLiveData<LoginFormState> loginFormState = new MutableLiveData<>();
    private MutableLiveData<LoginResult> loginResult = new MutableLiveData<>();
    private LoginRepository loginRepository;
    private UserLoginDatabase userLoginDatabase;

    public LoginViewModel(Context context){
        userLoginDatabase = new UserLoginDatabase(context);
    }

    LoginViewModel(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    LiveData<LoginFormState> getLoginFormState() {
        return loginFormState;
    }

    LiveData<LoginResult> getLoginResult() {
        return loginResult;
    }

    public void login(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            loginResult.setValue(new LoginResult(R.string.login_failed));
            return;
        }

        boolean validUser = userLoginDatabase.findUserLogin(username, password);

        if (validUser) {
            // Login success
            loginResult.setValue(new LoginResult(new LoggedInUserView(username)));
        } else {
            // User doesn't exist or wrong password
            boolean userExists = checkUsernameExists(username);
            if (userExists) {
                // User exists but wrong password
                loginResult.setValue(new LoginResult(R.string.invalid_password));
            } else {
                // New user, create account
                userLoginDatabase.addUser(username, password, password);  // confirm password same as password here
                loginResult.setValue(new LoginResult(new LoggedInUserView(username)));
            }
        }
    }
    private boolean checkUsernameExists(String username) {
        SQLiteDatabase db = userLoginDatabase.getReadableDatabase();
        Cursor cursor = null;
        try {
            String[] columns = {UserLoginDatabase.LoginsTable.Col_Username};
            String selection = UserLoginDatabase.LoginsTable.Col_Username + " = ?";
            String[] selectionArgs = {username};
            cursor = db.query(UserLoginDatabase.LoginsTable.TABLE, columns, selection, selectionArgs, null, null, null);
            return cursor.getCount() > 0;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

        public void loginDataChanged (String username, String password){
            if (!isUserNameValid(username)) {
                loginFormState.setValue(new LoginFormState(R.string.invalid_username, null));
            } else if (!isPasswordValid(password)) {
                loginFormState.setValue(new LoginFormState(null, R.string.invalid_password));
            } else {
                loginFormState.setValue(new LoginFormState(true));
            }
        }


    // A placeholder username validation check
    private boolean isUserNameValid(String username) {
        if (username == null) {
            return false;
        }
        if (username.contains("@")) {
            return Patterns.EMAIL_ADDRESS.matcher(username).matches();
        } else {
            return !username.trim().isEmpty();
        }
    }

    // A placeholder password validation check
    private boolean isPasswordValid(String password) {
        return password != null && password.trim().length() > 5;
    }
}