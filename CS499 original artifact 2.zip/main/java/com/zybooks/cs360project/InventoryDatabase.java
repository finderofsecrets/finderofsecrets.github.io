package com.zybooks.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    private static InventoryDatabase instance;

    public static synchronized InventoryDatabase getInstance(Context context){
        if (instance == null){
            instance = new InventoryDatabase(context.getApplicationContext());
        }
        return instance;
    }

    private InventoryDatabase (Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class InventoryTable {
        private static final String TABLE = "Inventory";
        private static final String COL_ID = "Item_Number";
        private static final String Col_Item= "Item";
        private static final String Col_Qty = "Quantity";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + InventoryTable.TABLE + " (" +
                InventoryTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InventoryTable.Col_Item + " TEXT NOT NULL, " +
                InventoryTable.Col_Qty + " INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + InventoryTable.TABLE);
        onCreate(db);
    }

    public void addItem(String item, int qty){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.Col_Item, item);
        values.put(InventoryTable.Col_Qty, qty);
        try {
            db.insertOrThrow(InventoryTable.TABLE, null, values);
        } catch (SQLException e) {
            System.out.println("Item already exists");
        }
    }

    public void deleteItem(String itemNumber){
        SQLiteDatabase db = getWritableDatabase();
        int toDelete = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?", new String[]{itemNumber});
    }

    public void adjustQty(String itemNumber, int newQty){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryTable.Col_Qty, newQty);
        int changeQuantity = db.update(InventoryTable.TABLE, values, InventoryTable.COL_ID + " = ? ", new String[]{itemNumber});
    }

    public List<InventoryItem> getAllItems(){
        List<InventoryItem> itemList = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + InventoryTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);

        if(cursor.moveToFirst()){
            do {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int qty = cursor.getInt(2);
                itemList.add(new InventoryItem(id, name, qty));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }



}
