package com.zybooks.cs360project;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder>{

    private final List<InventoryItem> itemList;

    public InventoryAdapter(List<InventoryItem> itemList){
        this.itemList = itemList;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView itemNumberTextView;
        TextView itemNameTextView;
        TextView itemQTYTextView;

        public ViewHolder(View itemView){
            super(itemView);
            itemNumberTextView = itemView.findViewById(R.id.itemNumberTextView);
            itemNameTextView = itemView.findViewById(R.id.itemNameTextView);
            itemQTYTextView = itemView.findViewById(R.id.itemQtyTextView);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.inventory_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position){
        InventoryItem item = itemList.get(position);
        holder.itemNumberTextView.setText("Item #: " + item.getItemNumber());
        holder.itemNameTextView.setText(" Item Name: " + item.getItemName());
        holder.itemQTYTextView.setText(" Quantity: " + item.getQty());
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }


}
